
package parcial;

import java.util.Scanner;

public class Parcial {

    public static void main(String[] args) {
      Scanner SC = new Scanner(System.in);
        int[] numeros = new int[5];
        int[] secreto = new int[5];
        int contador = 0;
        
        for (int i = 0; i < secreto.length; i++) {
            secreto[i] = (int)(Math.random() * 31) + 100;
            for (int j = 0; j < i; j++) {
                if (secreto[i] == secreto[j]) {
                    i--; 
                    break;
                }
            }
        }
        
        System.out.println("Ingresa 5 numeros entre 100 y 130.");
        System.out.println("si acierta minimo 2 numeros su nota es: 4.80");
        System.out.println("pero si solo acierta 1 su nota es:  3.0");
        
        for (int i = 0; i < 5; i++){
        System.out.println("Vas por el numero/"+(i+1)+"/ingresa otro:");
        numeros[i] = SC.nextInt();
        }
        
       for(int i = 0; i < numeros.length; i++){
           for(int l = 0; l <secreto.length; l++){
if (numeros[i] == secreto[l]) {
    contador++;
}

        }           
       }         
        if(contador > 2){
              System.out.println("Aprobaste con esta nota: 4.80");
              System.out.println("cantidad aprobada:"+contador);
          }
          else {
              System.out.println("Aprobaste con esta nota: 3.0");
              System.out.println("cantidad aprobada:"+contador);
          }
        SC.close();
    }
}